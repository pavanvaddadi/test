import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {AddUserComponent} from './registration/add-user/add-user.component';
import {UserLoginComponent} from './login/user-login/user-login.component';
import {UserInfoComponent} from './user-details/user-info/user-info.component';


const routes: Routes = [
  {path: '', redirectTo: 'user-login', pathMatch: 'full'},
  {path: 'user-login', component: UserLoginComponent},
  {path: 'add-user', component: AddUserComponent},
  {path: 'user-details/:id', component: UserInfoComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {


}
