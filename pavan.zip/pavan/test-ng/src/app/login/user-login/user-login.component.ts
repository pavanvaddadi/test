import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {Router} from '@angular/router';

@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.less']
})
export class UserLoginComponent implements OnInit {

  public loginForm: FormGroup;
  public isFormSubmitted = false;
  public isAuthUser = true;

  get getFormData() { return this.loginForm.controls; }

  constructor(private fb: FormBuilder, private  router: Router) { }

  ngOnInit(): void {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(8)]],
    });
  }

  public onSubmit() {
    this.isFormSubmitted = true;
    //
    if (this.loginForm.valid) {
      const newKeys = Object.keys(localStorage);
      let userId;
      let isValidUser = false;
      for (const i of newKeys) {
        const email = JSON.parse(localStorage.getItem(i)).email;
        const pwd = JSON.parse(localStorage.getItem(i)).password;


        // tslint:disable-next-line:triple-equals
        if (this.loginForm.get('email').value == email && this.loginForm.get('password').value == pwd) {
          userId = i;
          isValidUser = true;
        }

        // tslint:disable-next-line:triple-equals
        if (isValidUser != true) {
        } else {
          break;
        }
      }

      if (isValidUser) {
        this.isAuthUser = true;
        this.router.navigate(['/user-details/', userId]).then();
      } else {
         this.isAuthUser = false;
      }
      }
  }

}
