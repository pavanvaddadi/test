import { Component, OnInit } from '@angular/core';
import {ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-user-info',
  templateUrl: './user-info.component.html',
  styleUrls: ['./user-info.component.less']
})
export class UserInfoComponent implements OnInit {

  public selectedUser: string;
  public userData: object;

  constructor(private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    this.selectedUser = this.activatedRoute.snapshot.params.id;
    this.userData = JSON.parse(localStorage.getItem(this.selectedUser));
    console.log(this.userData);
  }

}
