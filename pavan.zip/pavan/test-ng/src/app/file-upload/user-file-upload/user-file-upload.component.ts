import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-file-upload',
  templateUrl: './user-file-upload.component.html',
  styleUrls: ['./user-file-upload.component.less']
})
export class UserFileUploadComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
