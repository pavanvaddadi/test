import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserFileUploadComponent } from './user-file-upload/user-file-upload.component';



@NgModule({
  declarations: [UserFileUploadComponent],
  imports: [
    CommonModule
  ]
})
export class FileUploadModule { }
